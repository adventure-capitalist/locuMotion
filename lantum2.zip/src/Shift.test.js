import React from 'react';
import { render, unmountComponentAtNode } from '@testing-library/react';
import {Shift} from "./components/Shift";
let container = null;


beforeEach(() => {
    // setup a DOM element as a render target
    container = document.createElement("div");
    document.body.appendChild(container);
  });
  
  afterEach(() => {
    // cleanup on exiting
    unmountComponentAtNode(container);
    container.remove();
    container = null;
  });
  
  it("renders shift data", async () => {
    const fakeShift = {
      practice: {name: "The best hospital"},
      startDateTime: "Wed Mar 25 2015 05:00:00 GMT+0000",
      endDateTime: "Wed Mar 25 2015 08:00:00 GMT+0000",
      hourlyRate: 10,
      locum: null
    };
    jest.spyOn(global, "fetch").mockImplementation(() =>
      Promise.resolve({
        json: () => Promise.resolve(fakeShift)
      })
    );
  
    // Use the asynchronous version of act to apply resolved promises
    await act(async () => {
      render(<Shift fakeShift={fakeShift}/>, container);
    });
  
    expect(container.querySelector(".rate").textContent).toContain(fakeShift.practice.name);
    expect(container.querySelector(".shiftHeader").textContent).toContain(fakeShift.age);
  
    // remove the mock to ensure tests are completely isolated
    global.fetch.mockRestore();
  });
  